import {Injectable} from '@angular/core'
import {Http} from '@angular/http'
@Injectable()
export class DataService
{
    constructor(private http:Http){}
    getsign(day,month)
    {
        console.log(day);
        return this.http.post("http://localhost:8080/api/hi",JSON.stringify({day:day,month:month}));
    }   
}