import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-predzodiac',
  templateUrl: './predzodiac.component.html',
  styleUrls: ['./predzodiac.component.css']
})
export class PredzodiacComponent implements OnInit {


  constructor(private dataservice:DataService) { }

  ngOnInit() {
  }
  day="";
  month="";
  data="Enter Day & Month to display Zodiac Sign"
  Onsave()
  {
    this.dataservice.getsign(this.day,this.month)
    .subscribe(
      (response)=>{
        this.data=response.text();
      },
      (error)=>console.log(error),
    );    
  }
  
}
