import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredzodiacComponent } from './predzodiac.component';

describe('PredzodiacComponent', () => {
  let component: PredzodiacComponent;
  let fixture: ComponentFixture<PredzodiacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredzodiacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredzodiacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
